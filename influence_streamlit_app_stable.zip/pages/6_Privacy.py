
import streamlit as st

st.set_page_config(page_title="隱私與免責", layout="centered")
st.title("隱私與免責聲明")

st.write("- 我們重視您的個人資料保護，僅在提供服務之目的範圍內蒐集與使用。  
"
         "- 您可要求查詢、更正或刪除個人資料，詳情請與我們聯繫。  
"
         "- 本平台之計算結果與建議僅供初步規劃參考，實際方案須由專業顧問複核與法令許可範圍內執行。")
