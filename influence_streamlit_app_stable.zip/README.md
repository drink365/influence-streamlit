# 影響力｜永傳家族傳承平台（MVP • Streamlit）

雲端部署教學：
1) 將本專案上傳到 GitHub repo `influence-streamlit`
2) 在 Streamlit Cloud 新增 App，入口點 `app.py`，Python 版本由 `runtime.txt` 指定為 3.12
